﻿namespace employeeCRUD.Models
{
    public class DepartmentViewModel
    {
        public int DepartmentId { get; set; }

        public string DepartmentName { get; set; }
    }
}
