﻿namespace EmployeeManagement.Models
{
    public enum Dept
    {
        None,
        Hr,
        IT,
        Payroll
    }
}
